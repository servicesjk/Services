<?php

echo company_widget($contract_info->company_id);
